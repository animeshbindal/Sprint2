import { Component, OnInit } from '@angular/core';
import { Booking } from '../onlinemovie';
import { BookingServiceService } from '../booking-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.scss']
})
export class ViewBookingComponent implements OnInit {
  info : String;
  errorInfo : String;
  booking:Booking=new Booking();
  bookingId:number;
  constructor(private route: ActivatedRoute,private router: Router,private bookingService:BookingServiceService) { }

  ngOnInit(): void {
    this.booking=new Booking();
      this.bookingId = this.route.snapshot.params['bookingId'];
      this.bookingDetails(this.bookingId);
  }
  bookingDetails(bookingId:number){
    this.bookingService.getBooking(bookingId).subscribe(data=>this.booking=data);
  }

}
