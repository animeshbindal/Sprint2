import { TestBed } from '@angular/core/testing';

import { ManageTheaterService } from './manage-theater.service';

describe('ManageTheaterService', () => {
  let service: ManageTheaterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ManageTheaterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
