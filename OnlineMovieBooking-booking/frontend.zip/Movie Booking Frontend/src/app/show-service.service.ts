import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Show } from './onlinemovie';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShowServiceService {
  baseUrl="http://localhost:8084/";
  constructor(private http:HttpClient) { }

  public addShow(show:Show){
    
    return this.http.post("http://localhost:8084/addShow",show,{responseType:'text'});
  }

  deleteShow(showId:number){
    console.log(showId);
     return this.http.delete("http://localhost:8084/deleteShow/"+showId,{responseType:'text'});
  }

  viewShow(showId:number):Observable<any>{
    return this.http.get(this.baseUrl+"viewShow/"+showId);
  }
  viewAllShow():Observable<any>{
    return this.http.get(this.baseUrl+"viewAllShow");
  }
}
