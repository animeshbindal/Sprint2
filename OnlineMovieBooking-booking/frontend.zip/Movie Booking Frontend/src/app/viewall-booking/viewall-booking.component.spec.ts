import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewallBookingComponent } from './viewall-booking.component';

describe('ViewallBookingComponent', () => {
  let component: ViewallBookingComponent;
  let fixture: ComponentFixture<ViewallBookingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewallBookingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewallBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
