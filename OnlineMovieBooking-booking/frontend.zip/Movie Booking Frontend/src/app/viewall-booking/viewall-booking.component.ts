import { Component, OnInit } from '@angular/core';
import { BookingServiceService } from '../booking-service.service';
import { Booking } from '../onlinemovie';
import { Router } from '@angular/router';
import { ShowServiceService } from '../show-service.service';

@Component({
  selector: 'app-viewall-booking',
  templateUrl: './viewall-booking.component.html',
  styleUrls: ['./viewall-booking.component.scss']
})
export class ViewallBookingComponent implements OnInit {
  bookings:Booking;
  showId:number;
  msg:string;
  errorMsg:string;
  booking:Booking=new Booking();
  constructor(private bookingService:BookingServiceService, private showService:ShowServiceService,private router:Router) { }

  ngOnInit(): void {
    this.bookingService.getBookings().subscribe(data=>this.bookings=data);
  }
  loadDetails(bookingId:number){
    this.router.navigate(['getBooking',bookingId]);
  }
  cancelBooking(bookingId:number){
    this.bookingService.cancleBooking(bookingId).subscribe(data=>{
      this.msg=data;
      this.bookingService.getBooking(bookingId).subscribe(data=>{this.booking=data;
        this.msg=this.msg+" & "+this.booking.totalCost+"Rs refund will be Initiated";
        alert(this.msg);
      });
      
      this.bookingService.getBookings().subscribe(data=>this.bookings=data);
      this.router.navigate(['getBookings'])},
      error=>{this.errorMsg=JSON.parse(error.error).message;
        console.log(error.error);
      this.msg=undefined;
      alert(this.errorMsg)}
      );
  }
}
