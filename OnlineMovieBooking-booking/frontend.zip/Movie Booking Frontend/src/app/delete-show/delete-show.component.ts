import { Component, OnInit } from '@angular/core';
import { ShowServiceService } from '../show-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-delete-show',
  templateUrl: './delete-show.component.html',
  styleUrls: ['./delete-show.component.scss']
})
export class DeleteShowComponent implements OnInit {

  msg:String;
  errorMsg:String;
  showId:number;
  constructor(private showService:ShowServiceService,private route: ActivatedRoute,private router: Router) { }

  ngOnInit(): void {
  }
  deleteTheater(){
    console.log(this.showId);
    this.showService.deleteShow(this.showId).subscribe((data) =>{
      //console.log("data",data);
      this.msg="Show Deleted";
      this.errorMsg=undefined;
      this.showId=null;
      alert(this.msg);
      this.router.navigate(['viewAllShow']);
      },
      
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
    this.msg=undefined;
    alert(this.errorMsg)}
    );
  }

}
