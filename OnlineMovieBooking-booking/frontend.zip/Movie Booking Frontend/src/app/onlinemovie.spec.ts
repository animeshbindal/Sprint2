import { Onlinemovie } from './onlinemovie';

describe('Onlinemovie', () => {
  it('should create an instance', () => {
    expect(new Onlinemovie()).toBeTruthy();
  });
});
